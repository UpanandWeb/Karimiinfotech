var um = angular.module('userModule', []);

var qm = angular.module('questionsModule', []);

var app = angular.module('AppModule', ["userModule","questionsModule","ngRoute"]);


um.controller("regCtrl",f1);
um.controller("loginCtrl",f2);

qm.controller("addQuestionCtrl",f3);
qm.controller("addAnswerCtrl",f4);
qm.controller("chooseBestAnswerCtrl",f5);

function f1($scope,$http){
	// reg logic

	$scope.u = {};

	$scope.register = function(){
		$http.post("", $scope.u).then(function(response){
			alert("registeration success")
		},function(error){
			alert("failed");
		})
	}
}



function f2($scope,$http){
	// login logic
	$scope.loginData = {};

	$scope.login = function(){

		var url = "https://my-json-server.typicode.com/angularbyrk/data/users?username="+$scope.loginData.username+"&password="+$scope.loginData.password;
		$http.get(url).then(function(response){
			console.log(response);
			if(response.data.length==1)
				alert("success");
			else
				alert("invalid username and password");
		},function(error){
			alert("failure");
		});
	}

}
function f3($scope,$http){
	// add question logic
	$scope.q = {};

	$scope.addQuestion = function(){
		// lgic
	}
}
function f4($scope,$http){
	// add answer logic
	$scope.cQuestion = {};

	$scope.addAnswer = function(){
		$http.put(url, $scope.cQuestion).
				then(function(response){
					alert("answer added successfully");
				},function(error){
					alert("failed to add answer");
				});
	}
}
function f5($scope){
	$scope.cQuestion = {
										"id" : 1,
										"sdesc":" angular service problem",
										"details" : "i am using service method of module. but unable to create.",
										"answers" : [ 
											{
												"id":1,
												"uid":"s1",
												"answer":"please check docs"
											},
											{
												"id":2,
												"uid":"s2",
												"answer":"use moduleref.service function"
											}
										]
								}
}

app.config(function($routeProvider){

	$routeProvider.when("/register", {
		templateUrl:"views/register.html",
		controller:"regCtrl"
	})

	$routeProvider.when("/login", {
		templateUrl:"views/login.html",
		controller:"loginCtrl"
	})

	$routeProvider.when("/addQuestion", {
		templateUrl:"views/addQuestion.html",
		controller:"addQuestionCtrl"
	})

	$routeProvider.when("/addAnswer", {
		templateUrl:"views/addAnswer.html",
		controller:"addAnswerCtrl"
	})

	$routeProvider.when("/chooseBestAnswer", {
		templateUrl:"views/chooseBestAnswer.html",
		controller:"chooseBestAnswerCtrl"
	})

})